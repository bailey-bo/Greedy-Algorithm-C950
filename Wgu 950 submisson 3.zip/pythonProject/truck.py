class Truck:
    # Constructor used to store packages to truck objects
    def __init__(self, packages, distance, timeDone):
        self.packages = packages
        self.distance = distance
        self.timeDone = timeDone

